# Nexon — Protótipo interativo 0.2

Protótipo Flutter para Android e iOS, com identidade visual azul escuro e navegação funcional.

## O que já funciona nesta versão
- Navegação entre Início, Agenda, Hábitos, Finanças e Mais.
- Adicionar tarefas/compromissos (lista demonstrativa).
- Adicionar e marcar hábitos como concluídos.
- Cadastrar contas com nome, vencimento e valor.
- Lista de compras com inclusão e remoção de itens.
- Personalizar nome e estilo do ajudante pessoal.
- Painel de notificações demonstrativas.
- Área de transporte apresentada como módulo planejado, separado das demais áreas.

## Limitações importantes
Esta é uma demonstração local. Os dados ficam somente na memória enquanto o app está aberto; não há login, banco de dados, sincronização, notificações reais, integração de transporte ou publicação nas lojas. Os itens de exemplo são fictícios.

## Como executar
1. Instale o Flutter SDK e configure Android Studio (Android) ou Xcode (iOS/macOS).
2. Extraia o ZIP.
3. No terminal, entre na pasta do projeto.
4. Execute:
   ```bash
   flutter pub get
   flutter run
   ```

Para gerar Android:
```bash
flutter build apk --release
```
Para gerar iOS (em Mac com Xcode):
```bash
flutter build ios --release
```

## Identidade e decisões preservadas
- Nome do app: Nexon.
- Nome inicial do ajudante: Compasso, mas cada usuário poderá escolher outro.
- O ajudante é contextual, não uma aba fixa.
- Estilos: Tranquilo, Equilibrado, Firme e motivador.
- Transporte separado e conectado futuramente ao calendário/mapa.
- Cores: #102B50, #2678E8, #1D416B e #75BDFF.
