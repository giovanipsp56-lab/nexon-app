import 'package:flutter/material.dart';

void main() => runApp(const NexonApp());

const navy = Color(0xFF102B50);
const blue = Color(0xFF2678E8);
const panel = Color(0xFF1D416B);
const pale = Color(0xFFB9D5F5);
const glow = Color(0xFF75BDFF);

class NexonApp extends StatefulWidget {
  const NexonApp({super.key});
  @override
  State<NexonApp> createState() => _NexonAppState();
}
class _NexonAppState extends State<NexonApp> {
  int tab = 0;
  String helperName = 'Compasso';
  String tone = 'Equilibrado';
  final List<String> tasks = ['Separar horário para estudar'];
  final List<String> habits = ['Academia', 'Estudar 30 minutos', 'Beber água'];
  final Set<String> completedHabits = {};
  final List<Map<String, String>> bills = [
    {'name':'Internet', 'due':'05/11/2026', 'amount':'R\$ 99,90'},
    {'name':'Energia', 'due':'10/11/2026', 'amount':'R\$ 145,00'},
  ];
  final List<String> shopping = ['Arroz', 'Leite', 'Ovos'];
  final List<String> notices = ['Bem-vindo ao Nexon. Vamos organizar suas prioridades.'];

  void addText(List<String> list, String value) {
    final v = value.trim();
    if (v.isEmpty) return;
    setState(() => list.add(v));
  }
  void notify(String value) => setState(() => notices.insert(0, value));

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(name: helperName, tone: tone, taskCount: tasks.length,
        billCount: bills.length, habitCount: habits.length,
        onNavigate: (i) => setState(() => tab = i),
        onNotifications: () => setState(() => tab = 4)),
      AgendaPage(items: tasks, onAdd: (v) { addText(tasks,v); notify('Novo compromisso/tarefa: $v'); }),
      HabitsPage(items: habits, completed: completedHabits,
        onAdd: (v) => addText(habits,v),
        onToggle: (v) => setState(() { if (completedHabits.contains(v)) { completedHabits.remove(v); } else { completedHabits.add(v); } })),
      FinancePage(items: bills, onAdd: (name, due, amount) => setState(() {
        bills.add({'name':name,'due':due,'amount':amount});
        notices.insert(0, 'Conta cadastrada: $name vence em $due');
      })),
      MorePage(shopping: shopping, notices: notices,
        onAddShopping: (v) => addText(shopping,v),
        onRemoveShopping: (v) => setState(() => shopping.remove(v)),
        helperName: helperName, tone: tone,
        onSaveHelper: (n,t) => setState(() { helperName = n; tone = t; notify('Preferências do ajudante atualizadas.'); })),
    ];
    return MaterialApp(
      title: 'Nexon',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark, scaffoldBackgroundColor: navy,
        colorScheme: ColorScheme.fromSeed(seedColor: blue, brightness: Brightness.dark),
        useMaterial3: true,
        cardTheme: CardThemeData(color: panel, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
        inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: const Color(0xFF16365D),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none)),
      ),
      home: Scaffold(
        body: SafeArea(child: IndexedStack(index: tab, children: pages)),
        bottomNavigationBar: NavigationBar(
          backgroundColor: const Color(0xFF0B203B), indicatorColor: blue.withOpacity(.25),
          selectedIndex: tab, onDestinationSelected: (v) => setState(() => tab = v),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Início'),
            NavigationDestination(icon: Icon(Icons.calendar_month_outlined), label: 'Agenda'),
            NavigationDestination(icon: Icon(Icons.fitness_center_outlined), label: 'Hábitos'),
            NavigationDestination(icon: Icon(Icons.account_balance_wallet_outlined), label: 'Finanças'),
            NavigationDestination(icon: Icon(Icons.grid_view_rounded), label: 'Mais'),
          ],
        ),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  final String name, tone; final int taskCount, billCount, habitCount;
  final ValueChanged<int> onNavigate; final VoidCallback onNotifications;
  const HomePage({super.key, required this.name, required this.tone, required this.taskCount,
    required this.billCount, required this.habitCount, required this.onNavigate, required this.onNotifications});
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    Row(children: [const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('NEXON', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900, letterSpacing: 2)),
      Text('Seu dia. Seu controle.', style: TextStyle(color: pale))]),
      IconButton(onPressed: onNotifications, icon: const Icon(Icons.notifications_none_rounded, size: 28))]),
    const SizedBox(height: 20),
    Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [const CircleAvatar(backgroundColor: blue, child: Icon(Icons.auto_awesome, color: Colors.white)),
        const SizedBox(width: 10), const Expanded(child: Text('SEU AJUDANTE PESSOAL', style: TextStyle(color: pale, fontWeight: FontWeight.bold, fontSize: 12))),
        const Icon(Icons.circle, color: Colors.lightGreenAccent, size: 9)]),
      const SizedBox(height: 15),
      Text('Olá! Eu sou $name.', style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
      const SizedBox(height: 6),
      Text(_helperMessage(tone), style: const TextStyle(color: pale)),
      const SizedBox(height: 14),
      const Text('Vamos transformar seus planos em ações.', style: TextStyle(fontWeight: FontWeight.w600)),
    ]))),
    const SizedBox(height: 22),
    const _SectionTitle('VISÃO GERAL'),
    Row(children: [
      Expanded(child: _Metric('$taskCount','Tarefas')),
      const SizedBox(width: 8), Expanded(child: _Metric('$habitCount','Hábitos')),
      const SizedBox(width: 8), Expanded(child: _Metric('$billCount','Contas')),
    ]),
    const SizedBox(height: 22), const _SectionTitle('SUAS ÁREAS'),
    GridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisCount: 2,
      crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 1.65, children: [
        _Area(Icons.calendar_month,'Agenda',()=>onNavigate(1)),
        _Area(Icons.fitness_center,'Academia e hábitos',()=>onNavigate(2)),
        _Area(Icons.receipt_long,'Finanças',()=>onNavigate(3)),
        _Area(Icons.shopping_cart_outlined,'Lista de compras',()=>onNavigate(4)),
        _Area(Icons.notifications_active_outlined,'Notificações',onNotifications),
        _Area(Icons.directions_transit,'Transporte',()=>_info(context,'Transporte','Área planejada para ônibus, trens, atrasos e alternativas de viagem conectadas aos compromissos.')),
      ]),
    const SizedBox(height: 18),
    const Text('Protótipo interativo • Os dados ficam apenas nesta sessão de demonstração.', style: TextStyle(color: pale, fontSize: 12)),
  ]);
  String _helperMessage(String t) => t == 'Firme e motivador'
    ? 'Vou cobrar suas prioridades com firmeza e lembrar o impacto de deixar tudo para depois.'
    : t == 'Tranquilo' ? 'Vamos no seu ritmo, organizando uma coisa de cada vez.' : 'Vou acompanhar suas prioridades e ajudar você a manter o equilíbrio.';
}
class AgendaPage extends StatelessWidget {
  final List<String> items; final ValueChanged<String> onAdd;
  const AgendaPage({super.key, required this.items, required this.onAdd});
  @override Widget build(BuildContext context) => _ListPage(title:'Agenda e compromissos',
    subtitle:'Organize tarefas e compromissos do seu dia.', icon:Icons.calendar_month, items:items,
    actionLabel:'Adicionar compromisso', onAdd:onAdd);
}
class HabitsPage extends StatelessWidget {
  final List<String> items; final Set<String> completed; final ValueChanged<String> onAdd; final ValueChanged<String> onToggle;
  const HabitsPage({super.key, required this.items, required this.completed, required this.onAdd, required this.onToggle});
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const _PageHeading('Academia e hábitos','Acompanhe pequenas ações que constroem consistência.',Icons.fitness_center),
    Card(child: Column(children: items.map((v)=>CheckboxListTile(value:completed.contains(v), onChanged:(_)=>onToggle(v),
      title:Text(v), activeColor:blue, secondary:const Icon(Icons.flag_outlined,color:glow))).toList())),
    const SizedBox(height:12), FilledButton.icon(onPressed:()=>_ask(context,'Novo hábito',onAdd),icon:const Icon(Icons.add),label:const Text('Adicionar hábito')),
    const SizedBox(height:12), Text('${completed.length} de ${items.length} hábitos concluídos nesta sessão.',style:const TextStyle(color:pale)),
  ]);
}
class FinancePage extends StatelessWidget {
  final List<Map<String,String>> items; final Function(String,String,String) onAdd;
  const FinancePage({super.key, required this.items, required this.onAdd});
  @override Widget build(BuildContext context) => ListView(padding:const EdgeInsets.all(20),children:[
    const _PageHeading('Finanças','Contas com data de vencimento e valor.',Icons.account_balance_wallet),
    ...items.map((b)=>Card(child:ListTile(leading:const Icon(Icons.receipt_long,color:glow),
      title:Text(b['name']??''),subtitle:Text('Vence em ${b['due']}'),trailing:Text(b['amount']??'',style:const TextStyle(fontWeight:FontWeight.bold))))),
    const SizedBox(height:12), FilledButton.icon(onPressed:()=>_billDialog(context,onAdd),icon:const Icon(Icons.add),label:const Text('Cadastrar conta')),
    const SizedBox(height:12), const Text('No protótipo, os vencimentos são apenas informativos: ainda não há alertas automáticos.',style:TextStyle(color:pale,fontSize:12)),
  ]);
}
class MorePage extends StatelessWidget {
  final List<String> shopping, notices; final ValueChanged<String> onAddShopping; final ValueChanged<String> onRemoveShopping;
  final String helperName,tone; final Function(String,String) onSaveHelper;
  const MorePage({super.key,required this.shopping,required this.notices,required this.onAddShopping,required this.onRemoveShopping,
    required this.helperName,required this.tone,required this.onSaveHelper});
  @override Widget build(BuildContext context) => ListView(padding:const EdgeInsets.all(20),children:[
    const _PageHeading('Mais recursos','Ferramentas complementares do Nexon.',Icons.grid_view),
    const _SectionTitle('LISTA DE COMPRAS'),
    Card(child:Column(children:[
      ...shopping.map((v)=>ListTile(leading:const Icon(Icons.shopping_bag_outlined,color:glow),title:Text(v),
        trailing:IconButton(onPressed:()=>onRemoveShopping(v),icon:const Icon(Icons.close)))),
      Padding(padding:const EdgeInsets.all(12),child:OutlinedButton.icon(onPressed:()=>_ask(context,'Adicionar item',onAddShopping),
        icon:const Icon(Icons.add),label:const Text('Adicionar item'))),
    ])),
    const SizedBox(height:18),const _SectionTitle('AJUDANTE PESSOAL'),
    Card(child:ListTile(leading:const Icon(Icons.auto_awesome,color:glow),title:Text(helperName),subtitle:Text('Estilo: $tone'),
      trailing:const Icon(Icons.chevron_right),onTap:()=>_helperDialog(context,helperName,tone,onSaveHelper))),
    const SizedBox(height:18),const _SectionTitle('NOTIFICAÇÕES'),
    Card(child: notices.isEmpty ? const ListTile(title:Text('Nenhum aviso por enquanto.')) :
      Column(children:notices.take(8).map((n)=>ListTile(dense:true,leading:const Icon(Icons.notifications_none,color:glow),title:Text(n))).toList())),
    const SizedBox(height:18),const _SectionTitle('TRANSPORTE'),
    Card(child:ListTile(leading:const Icon(Icons.directions_transit,color:glow),title:const Text('Ônibus, trens e mobilidade'),
      subtitle:const Text('Integração futura com mapa, horários e estimativas.'),
      onTap:()=>_info(context,'Transporte','Esta área será conectada ao calendário e ao mapa, sem misturar os dados com as outras áreas.'))),
  ]);
}
class _ListPage extends StatelessWidget {
  final String title,subtitle,actionLabel; final IconData icon; final List<String> items; final ValueChanged<String> onAdd;
  const _ListPage({required this.title,required this.subtitle,required this.icon,required this.items,required this.actionLabel,required this.onAdd});
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(20),children:[
    _PageHeading(title,subtitle,icon),
    if(items.isEmpty) const Card(child:Padding(padding:EdgeInsets.all(20),child:Text('Ainda não há itens cadastrados.',style:TextStyle(color:pale))))
    else ...items.map((v)=>Card(child:ListTile(leading:const Icon(Icons.event_note,color:glow),title:Text(v)))),
    const SizedBox(height:12),FilledButton.icon(onPressed:()=>_ask(context,actionLabel,onAdd),icon:const Icon(Icons.add),label:Text(actionLabel)),
    const SizedBox(height:10),const Text('Datas, horários e lembretes automáticos serão conectados na próxima fase.',style:TextStyle(color:pale,fontSize:12)),
  ]);
}
class _PageHeading extends StatelessWidget {
  final String title,subtitle; final IconData icon;
  const _PageHeading(this.title,this.subtitle,this.icon);
  @override Widget build(BuildContext context)=>Padding(padding:const EdgeInsets.only(bottom:20),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    Icon(icon,color:glow,size:34),const SizedBox(height:10),Text(title,style:const TextStyle(fontSize:25,fontWeight:FontWeight.bold)),
    const SizedBox(height:5),Text(subtitle,style:const TextStyle(color:pale)),
  ]));
}
class _SectionTitle extends StatelessWidget { final String text; const _SectionTitle(this.text);
  @override Widget build(BuildContext context)=>Text(text,style:const TextStyle(color:pale,fontWeight:FontWeight.bold,letterSpacing:1,fontSize:12)); }
class _Metric extends StatelessWidget { final String value,label; const _Metric(this.value,this.label);
  @override Widget build(BuildContext context)=>Card(child:Padding(padding:const EdgeInsets.symmetric(vertical:15),child:Column(children:[
    Text(value,style:const TextStyle(fontSize:25,fontWeight:FontWeight.bold)),Text(label,style:const TextStyle(color:pale,fontSize:12))]))); }
class _Area extends StatelessWidget { final IconData icon; final String label; final VoidCallback tap; const _Area(this.icon,this.label,this.tap);
  @override Widget build(BuildContext context)=>Card(child:InkWell(borderRadius:BorderRadius.circular(18),onTap:tap,child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,mainAxisAlignment:MainAxisAlignment.center,children:[
    Icon(icon,color:glow,size:25),const SizedBox(height:8),Text(label,style:const TextStyle(fontWeight:FontWeight.w600))])))); }
Future<void> _ask(BuildContext context,String title,ValueChanged<String> onSave) async {
  final c=TextEditingController();
  await showDialog(context:context,builder:(ctx)=>AlertDialog(title:Text(title),content:TextField(controller:c,autofocus:true,decoration:const InputDecoration(hintText:'Digite aqui')),
    actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Cancelar')),
      FilledButton(onPressed:(){onSave(c.text);Navigator.pop(ctx);},child:const Text('Adicionar'))]));
  c.dispose();
}
Future<void> _billDialog(BuildContext context,Function(String,String,String) onSave) async {
  final n=TextEditingController(),d=TextEditingController(),a=TextEditingController();
  await showDialog(context:context,builder:(ctx)=>AlertDialog(title:const Text('Cadastrar conta'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
    TextField(controller:n,decoration:const InputDecoration(labelText:'Nome da conta')),
    TextField(controller:d,decoration:const InputDecoration(labelText:'Vencimento (DD/MM/AAAA)')),
    TextField(controller:a,decoration:const InputDecoration(labelText:'Valor (R\$)'))])),
    actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Cancelar')),
      FilledButton(onPressed:(){if(n.text.trim().isNotEmpty){onSave(n.text.trim(),d.text.trim().isEmpty?'Não informado':d.text.trim(),a.text.trim().isEmpty?'Não informado':a.text.trim());}Navigator.pop(ctx);},child:const Text('Salvar'))]));
  n.dispose();d.dispose();a.dispose();
}
Future<void> _helperDialog(BuildContext context,String name,String tone,Function(String,String) onSave) async {
  final c=TextEditingController(text:name); String selected=tone;
  await showDialog(context:context,builder:(ctx)=>StatefulBuilder(builder:(ctx,setLocal)=>AlertDialog(title:const Text('Personalizar ajudante'),
    content:Column(mainAxisSize:MainAxisSize.min,children:[
      TextField(controller:c,decoration:const InputDecoration(labelText:'Nome do ajudante')),
      const SizedBox(height:12),DropdownButtonFormField<String>(value:selected,decoration:const InputDecoration(labelText:'Estilo'),
        items:const ['Tranquilo','Equilibrado','Firme e motivador'].map((v)=>DropdownMenuItem(value:v,child:Text(v))).toList(),
        onChanged:(v)=>setLocal(()=>selected=v??selected))]),
    actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Cancelar')),
      FilledButton(onPressed:(){onSave(c.text.trim().isEmpty?'Meu ajudante':c.text.trim(),selected);Navigator.pop(ctx);},child:const Text('Salvar'))])));
  c.dispose();
}
void _info(BuildContext context,String title,String message)=>showDialog(context:context,builder:(ctx)=>AlertDialog(title:Text(title),content:Text(message),actions:[
  TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Entendi'))]));
